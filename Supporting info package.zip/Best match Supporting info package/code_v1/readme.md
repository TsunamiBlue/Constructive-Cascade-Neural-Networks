requirements:
Python
numpy
Pytorch
matplotlib