Four files, each with 1,000 entries, the filenames give the label.

The SARS_data_example.xlsx file illustrates the fuzzy values. The 4 lines in that file are just an example and not part of the data.

The task is to predict the 4 labels.

